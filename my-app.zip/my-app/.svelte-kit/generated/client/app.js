export { matchers } from './matchers.js';

export const nodes = [
	() => import('./nodes/0'),
	() => import('./nodes/1'),
	() => import('./nodes/2'),
	() => import('./nodes/3'),
	() => import('./nodes/4'),
	() => import('./nodes/5'),
	() => import('./nodes/6'),
	() => import('./nodes/7'),
	() => import('./nodes/8'),
	() => import('./nodes/9'),
	() => import('./nodes/10'),
	() => import('./nodes/11'),
	() => import('./nodes/12'),
	() => import('./nodes/13'),
	() => import('./nodes/14'),
	() => import('./nodes/15'),
	() => import('./nodes/16'),
	() => import('./nodes/17'),
	() => import('./nodes/18'),
	() => import('./nodes/19'),
	() => import('./nodes/20'),
	() => import('./nodes/21'),
	() => import('./nodes/22'),
	() => import('./nodes/23'),
	() => import('./nodes/24')
];

export const server_loads = [];

export const dictionary = {
		"/": [2],
		"/admin": [3],
		"/admin/host": [4],
		"/admin/parasite": [5],
		"/host/chat": [6],
		"/host/home": [7],
		"/host/profile": [8],
		"/login": [9],
		"/parasite/chat": [10],
		"/parasite/home": [11],
		"/parasite/home/mission/activity": [12],
		"/parasite/home/mission/competition": [13],
		"/parasite/home/mission/exercises": [14],
		"/parasite/home/mission/mock": [15],
		"/parasite/home/resource/lecture": [16],
		"/parasite/home/resource/tip2": [18],
		"/parasite/home/resource/tip": [17],
		"/parasite/profile": [19],
		"/register/host": [20],
		"/register/host/success": [21],
		"/register/parasite": [22],
		"/register/parasite/success": [23],
		"/role": [24]
	};

export const hooks = {
	handleError: (({ error }) => { console.error(error) }),
	
	reroute: (() => {}),
	transport: {}
};

export const decoders = Object.fromEntries(Object.entries(hooks.transport).map(([k, v]) => [k, v.decode]));

export const hash = false;

export const decode = (type, value) => decoders[type](value);

export { default as root } from '../root.js';